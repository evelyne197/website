<?php
	$id = 'home';
?>
<!doctype html>
<html class="no-js" lang="de" id="<?=$id?>">
	<head>
		<meta charset="utf-8">
		<title>Evelyne Severing | Psychotherapie in Trier</title>
		<meta name="description" content="Evelyne Severing | Approbierte Psychologische Psychotherapeutin in Trier" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="resources/css/styles.min.css">
	</head>
	<body>
		<header>
			<div class="header__content">
				<div>
					<a class="logo" href="./index.php">Evelyne Severing</a>
					<button class="hamburger hamburger--spin" type="button">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
						<span class="hamburger-label">Menu</span>
					</button>
					<?php include('./includes/navigation.php'); ?>
				</div>
				<div class="stage">
					<picture>
						<source media="(max-width: 767px)" srcset="content/assets/small/1.jpg">
						<source media="(min-width: 768px)" srcset="content/assets/1.jpg">
						<img src="content/assets/1.jpg" alt="">
					</picture>
				</div>
			</div>
		</header>
		<main>
			<?php include('./content/html/index.html'); ?>
		</main>
		<?php include('./includes/footer.php'); ?>
		<script>
			var myApp = {};
		</script>
		<script src="resources/js/bundle.js"></script>
	</body>
</html>
