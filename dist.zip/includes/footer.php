<footer class="footer">
    <div class="footer__content">
        <ul>
            <li><a href="impressum.php">Impressum</a></li>
            <li><a href="datenschutz.php">Datenschutz</a></li>
        </ul>
    </div>
</footer>
